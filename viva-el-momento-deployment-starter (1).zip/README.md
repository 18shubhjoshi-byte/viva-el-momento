# Viva El Momento — KPS Class of 2027

A modern-retro, responsive registration **front-end preview** built with React + Vite.

## Important before publishing

This starter is a visual prototype:
- It does **not** save registrations to a database.
- It does **not** process or verify payments.
- The generated pass is a demo pass and is **not valid for event entry**.
- Do not enter real student information into this prototype.

Before accepting registrations or money, obtain school/parent/organiser approval and connect:
1. A secure backend/database with access controls.
2. A payment provider account owned/approved by the authorised school organiser.
3. Server-side payment verification (never trust a browser-only success screen).
4. A privacy notice, retention policy, and a process for corrections/refunds.

## Run locally

Install Node.js (LTS), then in this folder:

```bash
npm install
npm run dev
```

Open the local address printed by Vite.

## Build

```bash
npm run build
npm run preview
```

## Deploy to Vercel

1. Create a GitHub repository and upload this project.
2. Sign in to Vercel using the account approved by the school/organiser.
3. Choose **Add New → Project** and import the repository.
4. Vercel should detect Vite automatically.
5. Build command: `npm run build`
6. Output directory: `dist`
7. Select **Deploy**. Vercel will provide a public preview URL.
8. Test on phone and desktop before sharing.

You can also deploy the folder using Vercel's CLI, but the GitHub import route is easier for a first deployment.

## Event details

Update the `EVENT` object near the top of `src/main.jsx`:
- `date`
- `venue`
- `fee`

The current fee is shown as a **proposed fee only**. Keep registration/payment disabled until the amount and collection process are approved.
