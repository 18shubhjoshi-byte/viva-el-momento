import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { ArrowRight, ArrowLeft, Ticket, Sparkles, Check, Copy, Download, LockKeyhole } from "lucide-react";
import "./styles.css";

const EVENT = {
  name: "Viva El Momento",
  school: "KPS · CLASS OF 2027",
  fee: 500,
  date: "DATE TO BE ANNOUNCED",
  venue: "VENUE TO BE ANNOUNCED"
};

function makePass(name) {
  const clean = name.toUpperCase().replace(/[^A-Z0-9]/g, "");
  const suffix = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `KPS27-${(clean.slice(0, 3) || "GUE")}-${suffix}`;
}

function App() {
  const [step, setStep] = useState("home");
  const [form, setForm] = useState({ fullName: "", displayName: "", email: "", category: "Student" });
  const [pass, setPass] = useState("");
  const [copied, setCopied] = useState(false);

  const canContinue = form.fullName.trim().length > 1 && form.displayName.trim().length > 1 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email);

  const update = (key, value) => setForm(old => ({ ...old, [key]: value }));

  function finishDemo() {
    setPass(makePass(form.displayName));
    setStep("pass");
  }

  function downloadPass() {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="700"><rect width="1200" height="700" fill="#f3efe5"/><rect x="32" y="32" width="1136" height="636" rx="20" fill="none" stroke="#6e7659" stroke-width="3"/><text x="80" y="110" font-family="Georgia" font-size="26" fill="#6e7659" letter-spacing="6">KPS · CLASS OF 2027</text><text x="80" y="250" font-family="Georgia" font-size="82" fill="#292820">Viva El Momento</text><text x="82" y="330" font-family="Arial" font-size="28" fill="#6e7659">YOUR FAREWELL PASS</text><text x="82" y="445" font-family="Georgia" font-size="54" fill="#292820">${form.displayName.replace(/[&<>"]/g, "")}</text><text x="82" y="555" font-family="Arial" font-size="25" fill="#6e7659">${pass}</text><text x="1120" y="590" text-anchor="end" font-family="Arial" font-size="20" fill="#6e7659">DEMO PASS · NOT VALID FOR ENTRY</text></svg>`;
    const blob = new Blob([svg], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `viva-pass-${pass}.svg`; a.click();
    URL.revokeObjectURL(url);
  }

  async function copyPass() {
    try { await navigator.clipboard.writeText(pass); setCopied(true); setTimeout(() => setCopied(false), 1600); }
    catch { setCopied(false); }
  }

  return <main className="shell">
    <nav className="nav">
      <div className="brand"><span className="brand-mark">V.</span><span>VIVA EL MOMENTO</span></div>
      <span className="nav-note">KPS · CLASS OF 2027</span>
    </nav>

    {step === "home" && <section className="hero">
      <div className="eyebrow"><span className="dot"/> THE FAREWELL EDITION · 2027</div>
      <h1>One last chapter.<br/><em>A thousand</em> memories.</h1>
      <p className="intro">Some moments deserve more than a photograph. Join us as we celebrate the people, stories and little things that made these years ours.</p>
      <div className="details">
        <div><small>THE DATE</small><strong>{EVENT.date}</strong></div>
        <div><small>THE PLACE</small><strong>{EVENT.venue}</strong></div>
        <div><small>REGISTRATION</small><strong>₹{EVENT.fee} · proposed fee</strong></div>
      </div>
      <button className="primary" onClick={() => setStep("register")}>Begin registration <ArrowRight size={17}/></button>
      <div className="hero-foot"><span>01 — 03</span><span>MADE OF MOMENTS, KEPT FOREVER</span></div>
      <div className="seal">THE<br/>LAST<br/><i>EDIT</i></div>
    </section>}

    {step === "register" && <section className="form-wrap">
      <button className="back" onClick={() => setStep("home")}><ArrowLeft size={16}/> Back</button>
      <div className="eyebrow"><span className="dot"/> STEP 01 · YOUR DETAILS</div>
      <h2>Let's make<br/><em>it official.</em></h2>
      <p className="muted">Enter the name you'd like to see on your farewell pass.</p>
      <div className="form-grid">
        <label>Full name<input value={form.fullName} onChange={e => update("fullName", e.target.value)} placeholder="As per school records"/></label>
        <label>Name on your pass<input value={form.displayName} onChange={e => update("displayName", e.target.value)} placeholder="What should we call you?"/></label>
        <label>Email address<input type="email" value={form.email} onChange={e => update("email", e.target.value)} placeholder="you@example.com"/></label>
        <label>Joining as<select value={form.category} onChange={e => update("category", e.target.value)}><option>Student</option><option>Teacher</option><option>Invited guest</option></select></label>
      </div>
      <div className="notice"><LockKeyhole size={16}/> Demo only: this form does not transmit or save your details.</div>
      <button className="primary" disabled={!canContinue} onClick={() => setStep("review")}>Review registration <ArrowRight size={17}/></button>
    </section>}

    {step === "review" && <section className="form-wrap">
      <button className="back" onClick={() => setStep("register")}><ArrowLeft size={16}/> Edit details</button>
      <div className="eyebrow"><span className="dot"/> STEP 02 · CONFIRMATION</div>
      <h2>Almost<br/><em>there.</em></h2>
      <div className="review-card">
        <div><small>PASS NAME</small><strong>{form.displayName}</strong></div>
        <div><small>FULL NAME</small><strong>{form.fullName}</strong></div>
        <div><small>EMAIL</small><strong>{form.email}</strong></div>
        <div><small>REGISTRATION TYPE</small><strong>{form.category}</strong></div>
        <div className="fee"><small>PROPOSED EVENT FEE</small><strong>₹{EVENT.fee}</strong></div>
      </div>
      <div className="notice"><LockKeyhole size={16}/> Online payment is not connected. Do not collect money through this demo.</div>
      <button className="primary" onClick={finishDemo}>Create demo pass <Sparkles size={17}/></button>
    </section>}

    {step === "pass" && <section className="pass-wrap">
      <div className="eyebrow"><span className="dot"/> YOUR MOMENT, RESERVED — DEMO</div>
      <h2>See you<br/><em>there.</em></h2>
      <div className="ticket-card">
        <div className="ticket-top"><span>KPS · CLASS OF 2027</span><Ticket size={20}/></div>
        <div className="ticket-title">Viva El<br/><em>Momento.</em></div>
        <div className="ticket-name">{form.displayName}</div>
        <div className="ticket-bottom"><span>PASS NUMBER<br/><b>{pass}</b></span><span>ENTRY PASS<br/><b>DEMO ONLY</b></span></div>
      </div>
      <div className="pass-actions"><button className="primary" onClick={downloadPass}><Download size={17}/> Download pass</button><button className="secondary" onClick={copyPass}><Copy size={16}/> {copied ? "Copied" : "Copy pass number"}</button></div>
      <p className="fineprint">This is a visual preview only. It is not proof of registration or payment and cannot be used for event entry.</p>
      <button className="text-button" onClick={() => { setStep("home"); setForm({fullName:"",displayName:"",email:"",category:"Student"}); setPass(""); }}>Return to home</button>
    </section>}

    <footer><span>VIVA EL MOMENTO</span><span>AN ENDING, AND A BEGINNING.</span></footer>
  </main>;
}

createRoot(document.getElementById("root")).render(<App />);
